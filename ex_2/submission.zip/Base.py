# Python imports

# Third party imports

# Self imports


class BaseLayer:
    def __init__(self) -> None:
        self.trainable = False
        self.weights = None
